<?php
/**
 * Lo poco que queda en wp-admin: el registro de auditoría y las
 * actualizaciones del plugin.
 *
 * Acá vivían también «Usuarios» e «Invitaciones». Usuarios estaba roto de
 * raíz: listaba usuarios de WordPress, les cambiaba el rol de WordPress y los
 * suspendía con una usermeta, cuando desde el cutover de identidad los
 * promotores no tienen usuario de WordPress —esa pantalla editaba a otra gente,
 * o a nadie—. Las dos se rehicieron en el panel, en Equipo, sobre la cuenta y
 * su permiso sobre el panel, que es lo que decide de verdad quién entra.
 *
 * Lo que queda es de administrador del sitio, y ninguna de las dos cosas la
 * necesita nadie del equipo.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class PROMOTUR_Admin {

	private static $instance = null;
	const CAP = 'promotur_manage_users';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Capability para la página de Actualizaciones (la tienen los administradores). */
	const CAP_UPDATES = 'update_plugins';

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_promotur_admin_updates', array( $this, 'handle_updates' ) );
	}

	/* ----- Menú ----- */
	public function menu() {
		if ( ! current_user_can( self::CAP ) && ! current_user_can( self::CAP_UPDATES ) ) { return; }

		// El menú padre y su slug por defecto se gatean por la capability que tenga el rol.
		$parent_cap = current_user_can( self::CAP ) ? self::CAP : self::CAP_UPDATES;
		$parent_cb  = current_user_can( self::CAP ) ? array( $this, 'render_logs' ) : array( $this, 'render_updates' );
		add_menu_page( __( 'Portal Turismo', 'caaguazu-portal' ), __( 'Portal Turismo', 'caaguazu-portal' ), $parent_cap, 'promotur', $parent_cb, 'dashicons-palmtree', 57 );

		if ( current_user_can( self::CAP ) ) {
			add_submenu_page( 'promotur', __( 'Registros', 'caaguazu-portal' ), __( 'Registros', 'caaguazu-portal' ), self::CAP, 'promotur', array( $this, 'render_logs' ) );
		}
		add_submenu_page( 'promotur', __( 'Actualizaciones', 'caaguazu-portal' ), __( 'Actualizaciones', 'caaguazu-portal' ), self::CAP_UPDATES, 'promotur-updates', array( $this, 'render_updates' ) );
	}

	private function notice( $msg, $type = 'success' ) {
		set_transient( 'promotur_admin_notice_' . get_current_user_id(), array( 'm' => $msg, 't' => $type ), 60 );
	}
	private function show_notice() {
		$n = get_transient( 'promotur_admin_notice_' . get_current_user_id() );
		if ( $n ) {
			delete_transient( 'promotur_admin_notice_' . get_current_user_id() );
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $n['t'] ), wp_kses_post( $n['m'] ) );
		}
	}
	private function guard() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'No tenés autorización para hacer esto.', 'caaguazu-portal' ) );
		}
	}

	/* ================= LOGS ================= */
	public function render_logs() {
		$this->guard();
		$tab   = isset( $_GET['tab'] ) && 'posts' === $_GET['tab'] ? 'posts' : 'usuarios'; // phpcs:ignore WordPress.Security.NonceVerification
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification

		$actions = 'posts' === $tab
			? PROMOTUR_Audit::post_actions()
			// Lo que pasa con las cuentas y con el armado del panel. Los
			// `user_*` de antes describían usuarios de WordPress y ya no se
			// escriben: los eventos de equipo son sobre cuentas.
			: array(
				'login_success', 'login_failed', 'user_registered',
				'invitation_created', 'invitation_used', 'invitation_revoked',
				'equipo_rol', 'equipo_estado', 'equipo_quitado',
				'cuenta_editada', 'clave_cambiada',
				'media_borrada', 'estructura_creada', 'estructura_borrada',
			);

		$res = PROMOTUR_Audit::query( array( 'actions' => $actions, 'paged' => $paged, 'per_page' => 50 ) );
		$base = admin_url( 'admin.php?page=promotur-logs&tab=' . $tab );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Registros', 'caaguazu-portal' ); ?></h1>
			<h2 class="nav-tab-wrapper">
				<a class="nav-tab <?php echo 'usuarios' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=promotur-logs&tab=usuarios' ) ); ?>"><?php esc_html_e( 'Usuarios', 'caaguazu-portal' ); ?></a>
				<a class="nav-tab <?php echo 'posts' === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=promotur-logs&tab=posts' ) ); ?>"><?php esc_html_e( 'Entradas', 'caaguazu-portal' ); ?></a>
			</h2>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Fecha', 'caaguazu-portal' ); ?></th><th><?php esc_html_e( 'Usuario', 'caaguazu-portal' ); ?></th>
					<th><?php esc_html_e( 'Acción', 'caaguazu-portal' ); ?></th><th><?php esc_html_e( 'Elemento', 'caaguazu-portal' ); ?></th>
					<th><?php esc_html_e( 'IP', 'caaguazu-portal' ); ?></th><th><?php esc_html_e( 'Detalle', 'caaguazu-portal' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $res['rows'] ) ) : ?>
					<tr><td colspan="6"><?php esc_html_e( 'No hay registros.', 'caaguazu-portal' ); ?></td></tr>
				<?php else : foreach ( $res['rows'] as $r ) :
					$u = $r['user_id'] ? get_userdata( $r['user_id'] ) : null; ?>
					<tr>
						<td><?php echo esc_html( $r['created_at'] ); ?></td>
						<td><?php echo esc_html( $u ? $u->display_name : ( $r['user_id'] ? '#' . $r['user_id'] : '—' ) ); ?></td>
						<td><code><?php echo esc_html( $r['action'] ); ?></code></td>
						<td><?php echo esc_html( trim( $r['entity_type'] . ' ' . ( $r['entity_id'] ? '#' . $r['entity_id'] : '' ) ) ); ?></td>
						<td><?php echo esc_html( $r['ip'] ); ?></td>
						<td><?php echo $r['payload'] ? '<code>' . esc_html( $r['payload'] ) . '</code>' : '—'; ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
			<?php if ( $res['pages'] > 1 ) : ?>
				<p class="tablenav"><span class="pagination-links">
					<?php for ( $i = 1; $i <= $res['pages']; $i++ ) : ?>
						<a class="button button-small <?php echo $i === $paged ? 'button-primary' : ''; ?>" href="<?php echo esc_url( $base . '&paged=' . $i ); ?>"><?php echo (int) $i; ?></a>
					<?php endfor; ?>
				</span></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ================= ACTUALIZACIONES ================= */
	private function guard_updates() {
		if ( ! current_user_can( self::CAP_UPDATES ) ) {
			wp_die( esc_html__( 'No tenés autorización para hacer esto.', 'caaguazu-portal' ) );
		}
	}

	public function render_updates() {
		$this->guard_updates();

		$updater = function_exists( 'promotur_updater' ) ? promotur_updater() : null;

		// Versión instalada (header del plugin) y datos del plugin.
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$data      = get_plugin_data( PROMOTUR_FILE, false, false );
		$installed = $data['Version'] ? $data['Version'] : ( defined( 'PROMOTUR_VERSION' ) ? PROMOTUR_VERSION : '0' );

		// Última versión disponible (caché del updater) y última comprobación.
		$update      = $updater ? $updater->getUpdate() : null;
		$last_check  = 0;
		if ( $updater && method_exists( $updater, 'getUpdateState' ) ) {
			$state      = $updater->getUpdateState();
			$last_check = $state ? (int) $state->getLastCheck() : 0;
		}

		// Estado del token.
		$token_const = defined( 'PROMOTUR_GITHUB_TOKEN' ) && PROMOTUR_GITHUB_TOKEN;
		$token_opt   = (string) get_option( 'promotur_github_token', '' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Actualizaciones del portal', 'caaguazu-portal' ); ?></h1>
			<?php $this->show_notice(); ?>

			<?php if ( ! $updater ) : ?>
				<div class="notice notice-error"><p><?php esc_html_e( 'No se pudo iniciar el verificador de actualizaciones (plugin-update-checker). Revisá que la carpeta vendor/ esté presente.', 'caaguazu-portal' ); ?></p></div>
			<?php endif; ?>

			<?php if ( defined( 'PROMOTUR_VERSION' ) && version_compare( $installed, PROMOTUR_VERSION, '!=' ) ) : ?>
				<div class="notice notice-warning"><p>
					<?php printf(
						/* translators: 1: header version, 2: constant version */
						esc_html__( 'Atención: la versión del encabezado del plugin (%1$s) no coincide con PROMOTUR_VERSION (%2$s). El sistema de actualizaciones usa la versión del encabezado; mantenelas iguales para evitar problemas al publicar nuevas versiones.', 'caaguazu-portal' ),
						esc_html( $installed ),
						esc_html( PROMOTUR_VERSION )
					); ?>
				</p></div>
			<?php endif; ?>

			<table class="widefat striped" style="max-width:680px">
				<tbody>
					<tr><th style="width:200px"><?php esc_html_e( 'Versión instalada', 'caaguazu-portal' ); ?></th><td><code><?php echo esc_html( $installed ); ?></code></td></tr>
					<tr><th><?php esc_html_e( 'Última disponible', 'caaguazu-portal' ); ?></th><td>
						<?php if ( $update && ! empty( $update->version ) ) : ?>
							<code><?php echo esc_html( $update->version ); ?></code>
							<?php
							$link = wp_nonce_url(
								self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . rawurlencode( PROMOTUR_BASENAME ) ),
								'upgrade-plugin_' . PROMOTUR_BASENAME
							);
							?>
							&nbsp;<a class="button button-primary" href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Actualizar ahora', 'caaguazu-portal' ); ?></a>
						<?php else : ?>
							<?php esc_html_e( 'Estás al día.', 'caaguazu-portal' ); ?>
						<?php endif; ?>
					</td></tr>
					<tr><th><?php esc_html_e( 'Última comprobación', 'caaguazu-portal' ); ?></th><td>
						<?php echo $last_check ? esc_html( date_i18n( 'Y-m-d H:i', $last_check ) ) : esc_html__( 'nunca', 'caaguazu-portal' ); ?>
					</td></tr>
					<tr><th><?php esc_html_e( 'Repositorio', 'caaguazu-portal' ); ?></th><td><a href="<?php echo esc_url( PROMOTUR_REPO ); ?>" target="_blank" rel="noopener"><?php echo esc_html( PROMOTUR_REPO ); ?></a></td></tr>
				</tbody>
			</table>

			<p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
					<?php wp_nonce_field( 'promotur_admin_updates' ); ?>
					<input type="hidden" name="action" value="promotur_admin_updates">
					<input type="hidden" name="op" value="check">
					<button class="button"><?php esc_html_e( 'Buscar actualizaciones ahora', 'caaguazu-portal' ); ?></button>
				</form>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
					<?php wp_nonce_field( 'promotur_admin_updates' ); ?>
					<input type="hidden" name="action" value="promotur_admin_updates">
					<input type="hidden" name="op" value="reset">
					<button class="button"><?php esc_html_e( 'Limpiar caché del actualizador', 'caaguazu-portal' ); ?></button>
				</form>
			</p>

			<h2><?php esc_html_e( 'Token de GitHub', 'caaguazu-portal' ); ?></h2>
			<?php if ( $token_const ) : ?>
				<p><?php esc_html_e( 'Definido en wp-config.php mediante PROMOTUR_GITHUB_TOKEN. No se puede editar desde acá y tiene prioridad sobre el token guardado en la base de datos.', 'caaguazu-portal' ); ?></p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'El repositorio es público, así que normalmente no necesitás un token. Configurá uno si el repositorio pasa a ser privado o si alcanzás el límite de peticiones de GitHub.', 'caaguazu-portal' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'promotur_admin_updates' ); ?>
					<input type="hidden" name="action" value="promotur_admin_updates">
					<input type="hidden" name="op" value="save_token">
					<table class="form-table"><tbody>
						<tr><th><?php esc_html_e( 'Token', 'caaguazu-portal' ); ?></th><td>
							<input type="password" name="github_token" class="regular-text" autocomplete="off" placeholder="<?php echo $token_opt ? esc_attr__( '•••• guardado (dejá vacío para conservarlo)', 'caaguazu-portal' ) : 'ghp_…'; ?>">
							<?php if ( $token_opt ) : ?>
								<p><label><input type="checkbox" name="clear_token" value="1"> <?php esc_html_e( 'Eliminar el token guardado', 'caaguazu-portal' ); ?></label></p>
							<?php endif; ?>
						</td></tr>
					</tbody></table>
					<p><button class="button button-primary"><?php esc_html_e( 'Guardar token', 'caaguazu-portal' ); ?></button></p>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	public function handle_updates() {
		$this->guard_updates();
		check_admin_referer( 'promotur_admin_updates' );
		$op      = sanitize_key( wp_unslash( $_POST['op'] ?? '' ) );
		$updater = function_exists( 'promotur_updater' ) ? promotur_updater() : null;

		switch ( $op ) {
			case 'check':
				if ( $updater ) {
					$update = $updater->checkForUpdates();
					delete_site_transient( 'update_plugins' );
					if ( $update && ! empty( $update->version ) ) {
						$this->notice( sprintf( __( 'Hay una nueva versión disponible: %s.', 'caaguazu-portal' ), '<code>' . esc_html( $update->version ) . '</code>' ) );
					} else {
						$this->notice( __( 'No hay actualizaciones: ya tenés la última versión.', 'caaguazu-portal' ) );
					}
				} else {
					$this->notice( __( 'El verificador de actualizaciones no está disponible.', 'caaguazu-portal' ), 'error' );
				}
				break;

			case 'reset':
				if ( $updater && method_exists( $updater, 'resetUpdateState' ) ) {
					$updater->resetUpdateState();
				}
				delete_site_transient( 'update_plugins' );
				$this->notice( __( 'Caché del actualizador limpiada.', 'caaguazu-portal' ) );
				break;

			case 'save_token':
				if ( defined( 'PROMOTUR_GITHUB_TOKEN' ) && PROMOTUR_GITHUB_TOKEN ) {
					$this->notice( __( 'El token está definido en wp-config.php y no se puede cambiar desde acá.', 'caaguazu-portal' ), 'error' );
					break;
				}
				$clear = ! empty( $_POST['clear_token'] );
				$token = sanitize_text_field( wp_unslash( $_POST['github_token'] ?? '' ) );
				if ( $clear ) {
					delete_option( 'promotur_github_token' );
					$this->notice( __( 'Token eliminado.', 'caaguazu-portal' ) );
				} elseif ( '' !== $token ) {
					update_option( 'promotur_github_token', $token, false );
					$this->notice( __( 'Token guardado.', 'caaguazu-portal' ) );
				} else {
					$this->notice( __( 'No hubo cambios en el token.', 'caaguazu-portal' ) );
				}
				if ( class_exists( 'PROMOTUR_Audit' ) ) {
					PROMOTUR_Audit::log( 'update_settings', array( 'entity_type' => 'plugin' ) );
				}
				break;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=promotur-updates' ) );
		exit;
	}
}
